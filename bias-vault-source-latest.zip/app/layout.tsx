import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Bias Vault · Moderator workspace",
  description: "The card catalog and roster workspace for your K-pop game.",
};
export default function Layout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
